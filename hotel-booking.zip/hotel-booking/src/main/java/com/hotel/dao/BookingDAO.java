package com.hotel.dao;

import com.hotel.exception.AppException;
import com.hotel.model.Booking;
import com.hotel.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class BookingDAO {

    private static final String BOOKING_SELECT =
            "SELECT b.id, b.user_id, b.room_id, b.check_in, b.check_out, b.guests, b.total_amount, "
          + "b.status, b.created_at, r.room_number, t.name AS type_name, "
          + "u.full_name, u.email, p.method, p.status AS pay_status "
          + "FROM bookings b "
          + "JOIN rooms r ON b.room_id = r.id "
          + "JOIN room_types t ON r.type_id = t.id "
          + "JOIN users u ON b.user_id = u.id "
          + "LEFT JOIN payments p ON p.booking_id = b.id ";

    private Booking map(ResultSet rs) throws SQLException {
        Booking b = new Booking();
        b.setId(rs.getInt("id"));
        b.setUserId(rs.getInt("user_id"));
        b.setRoomId(rs.getInt("room_id"));
        b.setCheckIn(rs.getDate("check_in"));
        b.setCheckOut(rs.getDate("check_out"));
        b.setGuests(rs.getInt("guests"));
        b.setTotalAmount(rs.getBigDecimal("total_amount"));
        b.setStatus(rs.getString("status"));
        b.setCreatedAt(rs.getTimestamp("created_at"));
        b.setRoomNumber(rs.getString("room_number"));
        b.setTypeName(rs.getString("type_name"));
        b.setGuestName(rs.getString("full_name"));
        b.setGuestEmail(rs.getString("email"));
        b.setPaymentMethod(rs.getString("method"));
        b.setPaymentStatus(rs.getString("pay_status"));
        return b;
    }

    /**
     * CREATE: books a room and records the payment in ONE transaction.
     * The room row is locked (SELECT ... FOR UPDATE) so two guests cannot book the same room/dates.
     */
    public int create(Booking b, String paymentMethod) throws AppException {
        Connection c = null;
        try {
            c = DBConnection.getConnection();
            c.setAutoCommit(false);

            // 1. lock the room row
            try (PreparedStatement lock = c.prepareStatement(
                    "SELECT id FROM rooms WHERE id = ? AND status = 'ACTIVE' FOR UPDATE")) {
                lock.setInt(1, b.getRoomId());
                try (ResultSet rs = lock.executeQuery()) {
                    if (!rs.next()) {
                        throw new AppException("This room is not available for booking.");
                    }
                }
            }

            // 2. check overlapping bookings
            try (PreparedStatement chk = c.prepareStatement(
                    "SELECT COUNT(*) FROM bookings WHERE room_id = ? "
                  + "AND status IN ('CONFIRMED','CHECKED_IN') AND check_in < ? AND check_out > ?")) {
                chk.setInt(1, b.getRoomId());
                chk.setDate(2, b.getCheckOut());
                chk.setDate(3, b.getCheckIn());
                try (ResultSet rs = chk.executeQuery()) {
                    rs.next();
                    if (rs.getInt(1) > 0) {
                        throw new AppException("Sorry, this room was just booked for those dates. Please search again.");
                    }
                }
            }

            // 3. insert booking
            int bookingId;
            try (PreparedStatement ins = c.prepareStatement(
                    "INSERT INTO bookings (user_id, room_id, check_in, check_out, guests, total_amount, status) "
                  + "VALUES (?,?,?,?,?,?,'CONFIRMED')", Statement.RETURN_GENERATED_KEYS)) {
                ins.setInt(1, b.getUserId());
                ins.setInt(2, b.getRoomId());
                ins.setDate(3, b.getCheckIn());
                ins.setDate(4, b.getCheckOut());
                ins.setInt(5, b.getGuests());
                ins.setBigDecimal(6, b.getTotalAmount());
                ins.executeUpdate();
                try (ResultSet keys = ins.getGeneratedKeys()) {
                    keys.next();
                    bookingId = keys.getInt(1);
                }
            }

            // 4. insert payment
            String payStatus = "PAY_AT_HOTEL".equals(paymentMethod) ? "PENDING" : "PAID";
            try (PreparedStatement pay = c.prepareStatement(
                    "INSERT INTO payments (booking_id, amount, method, status) VALUES (?,?,?,?)")) {
                pay.setInt(1, bookingId);
                pay.setBigDecimal(2, b.getTotalAmount());
                pay.setString(3, paymentMethod);
                pay.setString(4, payStatus);
                pay.executeUpdate();
            }

            c.commit();
            return bookingId;
        } catch (SQLException e) {
            rollback(c);
            throw new AppException("Booking failed due to a database error.", e);
        } catch (AppException e) {
            rollback(c);
            throw e;
        } finally {
            close(c);
        }
    }

    /** READ: a guest's own bookings. */
    public List<Booking> findByUser(int userId) throws AppException {
        return query(BOOKING_SELECT + "WHERE b.user_id = ? ORDER BY b.created_at DESC", userId);
    }

    /** READ: all bookings (admin). */
    public List<Booking> findAll() throws AppException {
        return query(BOOKING_SELECT + "ORDER BY b.created_at DESC", null);
    }

    private List<Booking> query(String sql, Integer param) throws AppException {
        List<Booking> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            if (param != null) {
                ps.setInt(1, param);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
            return list;
        } catch (SQLException e) {
            throw new AppException("Could not load bookings.", e);
        }
    }

    /**
     * UPDATE: cancel a booking. Guests may only cancel their own CONFIRMED bookings;
     * admins may cancel any. A paid payment is marked REFUNDED.
     */
    public void cancel(int bookingId, int userId, boolean isAdmin) throws AppException {
        Connection c = null;
        try {
            c = DBConnection.getConnection();
            c.setAutoCommit(false);
            int rows;
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE bookings SET status = 'CANCELLED' "
                  + "WHERE id = ? AND status = 'CONFIRMED' AND (user_id = ? OR ?)")) {
                ps.setInt(1, bookingId);
                ps.setInt(2, userId);
                ps.setBoolean(3, isAdmin);
                rows = ps.executeUpdate();
            }
            if (rows == 0) {
                throw new AppException("This booking cannot be cancelled.");
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE payments SET status = 'REFUNDED' WHERE booking_id = ? AND status = 'PAID'")) {
                ps.setInt(1, bookingId);
                ps.executeUpdate();
            }
            c.commit();
        } catch (SQLException e) {
            rollback(c);
            throw new AppException("Could not cancel booking.", e);
        } catch (AppException e) {
            rollback(c);
            throw e;
        } finally {
            close(c);
        }
    }

    /** UPDATE: admin moves a booking through CHECKED_IN / CHECKED_OUT. */
    public void updateStatus(int bookingId, String status) throws AppException {
        if (!"CHECKED_IN".equals(status) && !"CHECKED_OUT".equals(status)) {
            throw new AppException("Invalid status.");
        }
        Connection c = null;
        try {
            c = DBConnection.getConnection();
            c.setAutoCommit(false);
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE bookings SET status = ? WHERE id = ? AND status <> 'CANCELLED'")) {
                ps.setString(1, status);
                ps.setInt(2, bookingId);
                ps.executeUpdate();
            }
            if ("CHECKED_OUT".equals(status)) {
                // guest settles any outstanding bill at check-out
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE payments SET status = 'PAID' WHERE booking_id = ? AND status = 'PENDING'")) {
                    ps.setInt(1, bookingId);
                    ps.executeUpdate();
                }
            }
            c.commit();
        } catch (SQLException e) {
            rollback(c);
            throw new AppException("Could not update booking status.", e);
        } finally {
            close(c);
        }
    }

    /** DELETE: admin removes a booking record. */
    public void delete(int bookingId) throws AppException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM bookings WHERE id = ?")) {
            ps.setInt(1, bookingId);
            ps.executeUpdate(); // payments are removed by ON DELETE CASCADE
        } catch (SQLException e) {
            throw new AppException("Could not delete booking.", e);
        }
    }

    /** Dashboard numbers for the admin. */
    public Map<String, Object> stats() throws AppException {
        Map<String, Object> m = new LinkedHashMap<>();
        try (Connection c = DBConnection.getConnection()) {
            m.put("totalRooms", scalar(c, "SELECT COUNT(*) FROM rooms"));
            m.put("totalGuests", scalar(c, "SELECT COUNT(*) FROM users WHERE role = 'GUEST'"));
            m.put("activeBookings", scalar(c, "SELECT COUNT(*) FROM bookings WHERE status IN ('CONFIRMED','CHECKED_IN')"));
            m.put("todayCheckIns", scalar(c, "SELECT COUNT(*) FROM bookings WHERE check_in = CURDATE() AND status = 'CONFIRMED'"));
            m.put("revenue", scalar(c, "SELECT COALESCE(SUM(amount),0) FROM payments WHERE status = 'PAID'"));
            return m;
        } catch (SQLException e) {
            throw new AppException("Could not load dashboard statistics.", e);
        }
    }

    private Object scalar(Connection c, String sql) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            rs.next();
            return rs.getObject(1);
        }
    }

    private void rollback(Connection c) {
        if (c != null) {
            try {
                c.rollback();
            } catch (SQLException ignored) {
                // nothing more we can do
            }
        }
    }

    private void close(Connection c) {
        if (c != null) {
            try {
                c.setAutoCommit(true);
                c.close();
            } catch (SQLException ignored) {
                // nothing more we can do
            }
        }
    }
}
