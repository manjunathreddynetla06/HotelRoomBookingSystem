package com.hotel.dao;

import com.hotel.exception.AppException;
import com.hotel.model.Room;
import com.hotel.model.RoomType;
import com.hotel.util.DBConnection;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RoomDAO {

    private static final int DUPLICATE_ENTRY = 1062;
    private static final int FK_VIOLATION = 1451;

    private static final String ROOM_SELECT =
            "SELECT r.id, r.room_number, r.type_id, r.floor_no, r.status, "
          + "t.name AS type_name, t.description, t.price_per_night, t.capacity "
          + "FROM rooms r JOIN room_types t ON r.type_id = t.id ";

    private Room map(ResultSet rs) throws SQLException {
        Room r = new Room();
        r.setId(rs.getInt("id"));
        r.setRoomNumber(rs.getString("room_number"));
        r.setTypeId(rs.getInt("type_id"));
        r.setFloorNo(rs.getInt("floor_no"));
        r.setStatus(rs.getString("status"));
        r.setTypeName(rs.getString("type_name"));
        r.setDescription(rs.getString("description"));
        r.setPricePerNight(rs.getBigDecimal("price_per_night"));
        r.setCapacity(rs.getInt("capacity"));
        return r;
    }

    /** READ all rooms */
    public List<Room> findAll() throws AppException {
        List<Room> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(ROOM_SELECT + "ORDER BY r.room_number");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(map(rs));
            }
            return list;
        } catch (SQLException e) {
            throw new AppException("Could not load rooms.", e);
        }
    }

    /** READ one room */
    public Room findById(int id) throws AppException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(ROOM_SELECT + "WHERE r.id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        } catch (SQLException e) {
            throw new AppException("Could not load room.", e);
        }
    }

    /** Active rooms (used when no dates are chosen). */
    public List<Room> findActive() throws AppException {
        List<Room> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(ROOM_SELECT + "WHERE r.status = 'ACTIVE' ORDER BY t.price_per_night, r.room_number");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(map(rs));
            }
            return list;
        } catch (SQLException e) {
            throw new AppException("Could not load rooms.", e);
        }
    }

    /** Rooms free for the whole stay and big enough for the guests. */
    public List<Room> findAvailable(Date checkIn, Date checkOut, int guests) throws AppException {
        String sql = ROOM_SELECT
                + "WHERE r.status = 'ACTIVE' AND t.capacity >= ? "
                + "AND r.id NOT IN (SELECT b.room_id FROM bookings b "
                + "  WHERE b.status IN ('CONFIRMED','CHECKED_IN') "
                + "  AND b.check_in < ? AND b.check_out > ?) "
                + "ORDER BY t.price_per_night, r.room_number";
        List<Room> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, guests);
            ps.setDate(2, checkOut);
            ps.setDate(3, checkIn);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
            return list;
        } catch (SQLException e) {
            throw new AppException("Could not search rooms.", e);
        }
    }

    /** CREATE */
    public void add(Room r) throws AppException {
        String sql = "INSERT INTO rooms (room_number, type_id, floor_no, status) VALUES (?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, r.getRoomNumber());
            ps.setInt(2, r.getTypeId());
            ps.setInt(3, r.getFloorNo());
            ps.setString(4, r.getStatus());
            ps.executeUpdate();
        } catch (SQLException e) {
            if (e.getErrorCode() == DUPLICATE_ENTRY) {
                throw new AppException("Room number " + r.getRoomNumber() + " already exists.", e);
            }
            throw new AppException("Could not add room.", e);
        }
    }

    /** UPDATE */
    public void update(Room r) throws AppException {
        String sql = "UPDATE rooms SET room_number = ?, type_id = ?, floor_no = ?, status = ? WHERE id = ?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, r.getRoomNumber());
            ps.setInt(2, r.getTypeId());
            ps.setInt(3, r.getFloorNo());
            ps.setString(4, r.getStatus());
            ps.setInt(5, r.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            if (e.getErrorCode() == DUPLICATE_ENTRY) {
                throw new AppException("Room number " + r.getRoomNumber() + " already exists.", e);
            }
            throw new AppException("Could not update room.", e);
        }
    }

    /** DELETE */
    public void delete(int id) throws AppException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM rooms WHERE id = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            if (e.getErrorCode() == FK_VIOLATION) {
                throw new AppException("This room has bookings and cannot be deleted. Set it to MAINTENANCE instead.", e);
            }
            throw new AppException("Could not delete room.", e);
        }
    }

    /** READ room types */
    public List<RoomType> findAllTypes() throws AppException {
        List<RoomType> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM room_types ORDER BY price_per_night");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                RoomType t = new RoomType();
                t.setId(rs.getInt("id"));
                t.setName(rs.getString("name"));
                t.setDescription(rs.getString("description"));
                t.setPricePerNight(rs.getBigDecimal("price_per_night"));
                t.setCapacity(rs.getInt("capacity"));
                list.add(t);
            }
            return list;
        } catch (SQLException e) {
            throw new AppException("Could not load room types.", e);
        }
    }
}
