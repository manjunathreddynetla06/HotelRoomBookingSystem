package com.hotel.servlet;

import com.hotel.dao.UserDAO;
import com.hotel.exception.AppException;
import com.hotel.model.User;
import com.hotel.util.PasswordUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static final Pattern EMAIL = Pattern.compile("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$");
    private static final Pattern PHONE = Pattern.compile("^[6-9]\\d{9}$");
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = trim(req.getParameter("fullName"));
        String email = trim(req.getParameter("email")).toLowerCase();
        String phone = trim(req.getParameter("phone"));
        String password = req.getParameter("password") == null ? "" : req.getParameter("password");
        String confirm = req.getParameter("confirm") == null ? "" : req.getParameter("confirm");

        // ---- server side validation ----
        List<String> errors = new ArrayList<>();
        if (name.length() < 3 || name.length() > 100) {
            errors.add("Full name must be 3 to 100 characters.");
        }
        if (!EMAIL.matcher(email).matches()) {
            errors.add("Enter a valid email address.");
        }
        if (!PHONE.matcher(phone).matches()) {
            errors.add("Enter a valid 10 digit Indian mobile number.");
        }
        if (password.length() < 6) {
            errors.add("Password must be at least 6 characters.");
        }
        if (!password.equals(confirm)) {
            errors.add("Passwords do not match.");
        }

        if (errors.isEmpty()) {
            User u = new User();
            u.setFullName(name);
            u.setEmail(email);
            u.setPhone(phone);
            u.setPasswordHash(PasswordUtil.hash(password));
            u.setRole("GUEST");
            try {
                userDAO.register(u);
                req.getSession(true).setAttribute("flash", "Registration successful. Please log in.");
                resp.sendRedirect(req.getContextPath() + "/login");
                return;
            } catch (AppException e) {
                errors.add(e.getMessage());
            }
        }

        req.setAttribute("errors", errors);
        req.setAttribute("fullName", name);
        req.setAttribute("email", email);
        req.setAttribute("phone", phone);
        req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req, resp);
    }

    private String trim(String s) {
        return s == null ? "" : s.trim();
    }
}
