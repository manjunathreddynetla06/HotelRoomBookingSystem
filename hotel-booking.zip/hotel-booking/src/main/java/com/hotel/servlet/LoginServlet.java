package com.hotel.servlet;

import com.hotel.dao.UserDAO;
import com.hotel.exception.AppException;
import com.hotel.model.User;
import com.hotel.util.PasswordUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.regex.Pattern;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static final Pattern EMAIL = Pattern.compile("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$");
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String email = req.getParameter("email") == null ? "" : req.getParameter("email").trim().toLowerCase();
        String password = req.getParameter("password") == null ? "" : req.getParameter("password");

        // ---- server side validation ----
        if (!EMAIL.matcher(email).matches() || password.isEmpty()) {
            fail(req, resp, email, "Enter a valid email and password.");
            return;
        }

        try {
            User user = userDAO.authenticate(email, PasswordUtil.hash(password));
            if (user == null) {
                fail(req, resp, email, "Invalid email or password.");
                return;
            }

            // prevent session fixation: discard old session, create a new one
            HttpSession old = req.getSession(false);
            String redirect = null;
            if (old != null) {
                redirect = (String) old.getAttribute("redirectAfterLogin");
                old.invalidate();
            }
            HttpSession session = req.getSession(true);
            session.setAttribute("user", user);
            session.setMaxInactiveInterval(30 * 60);

            String ctx = req.getContextPath();
            if (user.isAdmin()) {
                resp.sendRedirect(ctx + "/admin/dashboard");
            } else if (redirect != null && redirect.startsWith("/")) {
                resp.sendRedirect(ctx + redirect);
            } else {
                resp.sendRedirect(ctx + "/rooms");
            }
        } catch (AppException e) {
            fail(req, resp, email, e.getMessage());
        }
    }

    private void fail(HttpServletRequest req, HttpServletResponse resp, String email, String msg)
            throws ServletException, IOException {
        req.setAttribute("error", msg);
        req.setAttribute("email", email);
        req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, resp);
    }
}
