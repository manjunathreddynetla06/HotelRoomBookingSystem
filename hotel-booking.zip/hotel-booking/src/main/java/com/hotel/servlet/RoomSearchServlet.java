package com.hotel.servlet;

import com.hotel.dao.RoomDAO;
import com.hotel.exception.AppException;
import com.hotel.model.Room;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

/** Public page: browse rooms and search availability by date and guests. */
@WebServlet("/rooms")
public class RoomSearchServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private final RoomDAO roomDAO = new RoomDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String in = req.getParameter("checkIn");
        String out = req.getParameter("checkOut");
        String g = req.getParameter("guests");

        try {
            List<Room> rooms;
            if (in != null && !in.isEmpty() && out != null && !out.isEmpty()) {
                LocalDate checkIn;
                LocalDate checkOut;
                int guests;
                try {
                    checkIn = LocalDate.parse(in);
                    checkOut = LocalDate.parse(out);
                    guests = (g == null || g.isEmpty()) ? 1 : Integer.parseInt(g);
                } catch (DateTimeParseException | NumberFormatException e) {
                    throw new AppException("Invalid date or guest count.");
                }
                if (checkIn.isBefore(LocalDate.now())) {
                    throw new AppException("Check-in date cannot be in the past.");
                }
                if (!checkOut.isAfter(checkIn)) {
                    throw new AppException("Check-out must be after check-in.");
                }
                if (guests < 1 || guests > 10) {
                    throw new AppException("Guests must be between 1 and 10.");
                }
                rooms = roomDAO.findAvailable(Date.valueOf(checkIn), Date.valueOf(checkOut), guests);
                req.setAttribute("searched", true);
                req.setAttribute("nights", java.time.temporal.ChronoUnit.DAYS.between(checkIn, checkOut));
            } else {
                rooms = roomDAO.findActive();
            }
            req.setAttribute("rooms", rooms);
        } catch (AppException e) {
            req.setAttribute("error", e.getMessage());
        }

        req.setAttribute("checkIn", in);
        req.setAttribute("checkOut", out);
        req.setAttribute("guests", g == null || g.isEmpty() ? "1" : g);
        req.setAttribute("today", LocalDate.now().toString());
        req.getRequestDispatcher("/WEB-INF/views/rooms.jsp").forward(req, resp);
    }
}
