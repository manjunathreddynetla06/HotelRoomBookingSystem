package com.hotel.servlet;

import com.hotel.dao.BookingDAO;
import com.hotel.exception.AppException;
import com.hotel.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/** POST only: cancels the logged-in guest's booking. */
@WebServlet("/cancel")
public class CancelBookingServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private final BookingDAO bookingDAO = new BookingDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = (User) req.getSession().getAttribute("user");
        String msg;
        try {
            int id = Integer.parseInt(req.getParameter("bookingId"));
            bookingDAO.cancel(id, user.getId(), false);
            msg = "Booking #" + id + " cancelled.";
        } catch (NumberFormatException e) {
            msg = "Invalid booking.";
        } catch (AppException e) {
            msg = e.getMessage();
        }
        req.getSession().setAttribute("flash", msg);
        resp.sendRedirect(req.getContextPath() + "/my-bookings");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.sendRedirect(req.getContextPath() + "/my-bookings");
    }
}
