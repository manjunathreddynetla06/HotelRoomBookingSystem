package com.hotel.servlet;

import com.hotel.dao.BookingDAO;
import com.hotel.dao.RoomDAO;
import com.hotel.exception.AppException;
import com.hotel.model.Booking;
import com.hotel.model.Room;
import com.hotel.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;

/** GET: show the booking confirmation form. POST: create the booking. (Protected by AuthFilter.) */
@WebServlet("/book")
public class BookingServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static final List<String> METHODS = Arrays.asList("CARD", "UPI", "PAY_AT_HOTEL");
    private final RoomDAO roomDAO = new RoomDAO();
    private final BookingDAO bookingDAO = new BookingDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            prepare(req);
            req.getRequestDispatcher("/WEB-INF/views/book.jsp").forward(req, resp);
        } catch (AppException e) {
            req.getSession().setAttribute("flash", e.getMessage());
            resp.sendRedirect(req.getContextPath() + "/rooms");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = (User) req.getSession().getAttribute("user");
        try {
            Stay stay = prepare(req);

            String method = req.getParameter("paymentMethod");
            if (method == null || !METHODS.contains(method)) {
                throw new AppException("Please choose a payment method.");
            }

            Booking b = new Booking();
            b.setUserId(user.getId());
            b.setRoomId(stay.room.getId());
            b.setCheckIn(Date.valueOf(stay.checkIn));
            b.setCheckOut(Date.valueOf(stay.checkOut));
            b.setGuests(stay.guests);
            b.setTotalAmount(stay.total);

            int id = bookingDAO.create(b, method);
            req.getSession().setAttribute("flash", "Booking #" + id + " confirmed! Room " + stay.room.getRoomNumber() + ".");
            resp.sendRedirect(req.getContextPath() + "/my-bookings");
        } catch (AppException e) {
            req.setAttribute("error", e.getMessage());
            try {
                prepare(req);
                req.getRequestDispatcher("/WEB-INF/views/book.jsp").forward(req, resp);
            } catch (AppException e2) {
                req.getSession().setAttribute("flash", e2.getMessage());
                resp.sendRedirect(req.getContextPath() + "/rooms");
            }
        }
    }

    /** Validates request parameters, loads the room and puts everything the JSP needs on the request. */
    private Stay prepare(HttpServletRequest req) throws AppException {
        Stay s = new Stay();
        try {
            int roomId = Integer.parseInt(req.getParameter("roomId"));
            s.checkIn = LocalDate.parse(req.getParameter("checkIn"));
            s.checkOut = LocalDate.parse(req.getParameter("checkOut"));
            s.guests = Integer.parseInt(req.getParameter("guests"));
            s.room = roomDAO.findById(roomId);
        } catch (RuntimeException e) {
            throw new AppException("Invalid booking request. Please search again.");
        }
        if (s.room == null || !"ACTIVE".equals(s.room.getStatus())) {
            throw new AppException("Room not found or unavailable.");
        }
        if (s.checkIn.isBefore(LocalDate.now())) {
            throw new AppException("Check-in date cannot be in the past.");
        }
        if (!s.checkOut.isAfter(s.checkIn)) {
            throw new AppException("Check-out must be after check-in.");
        }
        if (s.guests < 1 || s.guests > s.room.getCapacity()) {
            throw new AppException("This room fits at most " + s.room.getCapacity() + " guest(s).");
        }
        long nights = ChronoUnit.DAYS.between(s.checkIn, s.checkOut);
        s.total = s.room.getPricePerNight().multiply(BigDecimal.valueOf(nights));

        req.setAttribute("room", s.room);
        req.setAttribute("checkIn", s.checkIn.toString());
        req.setAttribute("checkOut", s.checkOut.toString());
        req.setAttribute("guests", s.guests);
        req.setAttribute("nights", nights);
        req.setAttribute("total", s.total);
        return s;
    }

    private static class Stay {
        Room room;
        LocalDate checkIn;
        LocalDate checkOut;
        int guests;
        BigDecimal total;
    }
}
