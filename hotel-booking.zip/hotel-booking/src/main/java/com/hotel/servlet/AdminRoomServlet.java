package com.hotel.servlet;

import com.hotel.dao.RoomDAO;
import com.hotel.exception.AppException;
import com.hotel.model.Room;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.regex.Pattern;

/**
 * Admin room management (full CRUD).
 *   GET  /admin/rooms              list
 *   GET  /admin/rooms?action=new   empty form
 *   GET  /admin/rooms?action=edit&id=3   form filled with a room
 *   POST action=save               insert (id empty) or update (id set)
 *   POST action=delete             delete
 */
@WebServlet("/admin/rooms")
public class AdminRoomServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static final Pattern ROOM_NO = Pattern.compile("^[A-Za-z0-9]{1,10}$");
    private final RoomDAO roomDAO = new RoomDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        try {
            if ("new".equals(action) || "edit".equals(action)) {
                if ("edit".equals(action)) {
                    Room room = roomDAO.findById(Integer.parseInt(req.getParameter("id")));
                    if (room == null) {
                        throw new AppException("Room not found.");
                    }
                    req.setAttribute("room", room);
                }
                req.setAttribute("types", roomDAO.findAllTypes());
                req.getRequestDispatcher("/WEB-INF/views/admin/room-form.jsp").forward(req, resp);
                return;
            }
            req.setAttribute("rooms", roomDAO.findAll());
        } catch (AppException e) {
            req.setAttribute("error", e.getMessage());
        } catch (NumberFormatException e) {
            req.setAttribute("error", "Invalid room id.");
        }
        req.getRequestDispatcher("/WEB-INF/views/admin/rooms.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        String ctx = req.getContextPath();
        try {
            if ("delete".equals(action)) {
                roomDAO.delete(Integer.parseInt(req.getParameter("id")));
                req.getSession().setAttribute("flash", "Room deleted.");
            } else if ("save".equals(action)) {
                Room r = new Room();
                String idParam = req.getParameter("id");
                boolean isNew = idParam == null || idParam.isEmpty();
                if (!isNew) {
                    r.setId(Integer.parseInt(idParam));
                }
                String number = req.getParameter("roomNumber") == null ? "" : req.getParameter("roomNumber").trim();
                if (!ROOM_NO.matcher(number).matches()) {
                    throw new AppException("Room number must be 1-10 letters/digits.");
                }
                r.setRoomNumber(number);
                r.setTypeId(Integer.parseInt(req.getParameter("typeId")));
                int floor = Integer.parseInt(req.getParameter("floorNo"));
                if (floor < 0 || floor > 100) {
                    throw new AppException("Floor must be between 0 and 100.");
                }
                r.setFloorNo(floor);
                String status = req.getParameter("status");
                if (!"ACTIVE".equals(status) && !"MAINTENANCE".equals(status)) {
                    throw new AppException("Invalid status.");
                }
                r.setStatus(status);

                if (isNew) {
                    roomDAO.add(r);
                    req.getSession().setAttribute("flash", "Room " + number + " added.");
                } else {
                    roomDAO.update(r);
                    req.getSession().setAttribute("flash", "Room " + number + " updated.");
                }
            }
        } catch (NumberFormatException e) {
            req.getSession().setAttribute("flash", "Invalid number in form.");
        } catch (AppException e) {
            req.getSession().setAttribute("flash", e.getMessage());
        }
        resp.sendRedirect(ctx + "/admin/rooms");
    }
}
