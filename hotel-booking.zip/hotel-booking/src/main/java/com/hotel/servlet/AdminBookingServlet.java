package com.hotel.servlet;

import com.hotel.dao.BookingDAO;
import com.hotel.exception.AppException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/** Admin: view all bookings, check guests in/out, cancel or delete bookings. */
@WebServlet("/admin/bookings")
public class AdminBookingServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private final BookingDAO bookingDAO = new BookingDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            req.setAttribute("bookings", bookingDAO.findAll());
        } catch (AppException e) {
            req.setAttribute("error", e.getMessage());
        }
        req.getRequestDispatcher("/WEB-INF/views/admin/bookings.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        String msg;
        try {
            int id = Integer.parseInt(req.getParameter("id"));
            if ("checkin".equals(action)) {
                bookingDAO.updateStatus(id, "CHECKED_IN");
                msg = "Booking #" + id + " checked in.";
            } else if ("checkout".equals(action)) {
                bookingDAO.updateStatus(id, "CHECKED_OUT");
                msg = "Booking #" + id + " checked out.";
            } else if ("cancel".equals(action)) {
                bookingDAO.cancel(id, 0, true);
                msg = "Booking #" + id + " cancelled.";
            } else if ("delete".equals(action)) {
                bookingDAO.delete(id);
                msg = "Booking #" + id + " deleted.";
            } else {
                msg = "Unknown action.";
            }
        } catch (NumberFormatException e) {
            msg = "Invalid booking id.";
        } catch (AppException e) {
            msg = e.getMessage();
        }
        req.getSession().setAttribute("flash", msg);
        resp.sendRedirect(req.getContextPath() + "/admin/bookings");
    }
}
