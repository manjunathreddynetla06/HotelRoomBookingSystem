package com.hotel.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class Room implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private String roomNumber;
    private int typeId;
    private int floorNo;
    private String status;

    // joined from room_types
    private String typeName;
    private String description;
    private BigDecimal pricePerNight;
    private int capacity;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getRoomNumber() { return roomNumber; }
    public void setRoomNumber(String roomNumber) { this.roomNumber = roomNumber; }
    public int getTypeId() { return typeId; }
    public void setTypeId(int typeId) { this.typeId = typeId; }
    public int getFloorNo() { return floorNo; }
    public void setFloorNo(int floorNo) { this.floorNo = floorNo; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getTypeName() { return typeName; }
    public void setTypeName(String typeName) { this.typeName = typeName; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public BigDecimal getPricePerNight() { return pricePerNight; }
    public void setPricePerNight(BigDecimal pricePerNight) { this.pricePerNight = pricePerNight; }
    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }
}
