<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<jsp:include page="/WEB-INF/views/common/header.jsp"/>

<h2>Rooms</h2>

<form class="search-form search-inline" action="${ctx}/rooms" method="get" onsubmit="return validateSearch(this);">
    <label>Check-in
        <input type="date" name="checkIn" min="${today}" value="${checkIn}" required>
    </label>
    <label>Check-out
        <input type="date" name="checkOut" min="${today}" value="${checkOut}" required>
    </label>
    <label>Guests
        <input type="number" name="guests" min="1" max="10" value="${guests}" required>
    </label>
    <button class="btn" type="submit">Check availability</button>
</form>

<c:choose>
    <c:when test="${searched}">
        <p class="muted">
            <c:out value="${fn:length(rooms)}" default="0"/>
            room(s) available for <c:out value="${nights}"/> night(s)
            (<c:out value="${checkIn}"/> to <c:out value="${checkOut}"/>).
        </p>
    </c:when>
    <c:otherwise>
        <p class="muted">Choose dates above to see live availability and book.</p>
    </c:otherwise>
</c:choose>

<div class="grid">
    <c:forEach var="r" items="${rooms}">
        <div class="card room-card">
            <div class="room-head">
                <h3>Room <c:out value="${r.roomNumber}"/></h3>
                <span class="badge badge-${r.typeName}"><c:out value="${r.typeName}"/></span>
            </div>
            <p><c:out value="${r.description}"/></p>
            <ul class="meta">
                <li>Floor <c:out value="${r.floorNo}"/></li>
                <li>Up to <c:out value="${r.capacity}"/> guests</li>
            </ul>
            <div class="price">
                &#8377;<fmt:formatNumber value="${r.pricePerNight}" pattern="#,##0"/> <small>/ night</small>
            </div>
            <c:choose>
                <c:when test="${searched}">
                    <a class="btn btn-block"
                       href="${ctx}/book?roomId=${r.id}&amp;checkIn=${checkIn}&amp;checkOut=${checkOut}&amp;guests=${guests}">Book now</a>
                </c:when>
                <c:otherwise>
                    <span class="muted">Select dates to book</span>
                </c:otherwise>
            </c:choose>
        </div>
    </c:forEach>
</div>

<c:if test="${searched and empty rooms}">
    <div class="alert alert-info">No rooms are free for those dates. Try different dates or fewer guests.</div>
</c:if>

<script src="${ctx}/js/validate.js"></script>
<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
