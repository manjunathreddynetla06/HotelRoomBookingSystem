<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<jsp:include page="/WEB-INF/views/common/header.jsp"/>

<div class="form-box">
    <h2><c:out value="${empty room ? 'Add room' : 'Edit room'}"/></h2>

    <form action="${ctx}/admin/rooms" method="post">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="${room.id}">

        <label>Room number
            <input type="text" name="roomNumber" value="<c:out value='${room.roomNumber}'/>"
                   pattern="[A-Za-z0-9]{1,10}" maxlength="10" required>
        </label>

        <label>Room type
            <select name="typeId" required>
                <c:forEach var="t" items="${types}">
                    <option value="${t.id}" ${t.id == room.typeId ? 'selected' : ''}>
                        <c:out value="${t.name}"/> (<c:out value="${t.capacity}"/> guests)
                    </option>
                </c:forEach>
            </select>
        </label>

        <label>Floor
            <input type="number" name="floorNo" min="0" max="100" value="${empty room ? 1 : room.floorNo}" required>
        </label>

        <label>Status
            <select name="status" required>
                <option value="ACTIVE" ${room.status == 'ACTIVE' ? 'selected' : ''}>ACTIVE</option>
                <option value="MAINTENANCE" ${room.status == 'MAINTENANCE' ? 'selected' : ''}>MAINTENANCE</option>
            </select>
        </label>

        <button class="btn btn-block" type="submit">Save</button>
        <a class="btn btn-block btn-outline" href="${ctx}/admin/rooms">Cancel</a>
    </form>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
