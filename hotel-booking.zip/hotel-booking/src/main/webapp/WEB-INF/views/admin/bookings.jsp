<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<jsp:include page="/WEB-INF/views/common/header.jsp"/>

<h2>All bookings</h2>

<c:choose>
    <c:when test="${empty bookings}">
        <div class="alert alert-info">No bookings yet.</div>
    </c:when>
    <c:otherwise>
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th><th>Guest</th><th>Room</th><th>Stay</th><th>Total</th>
                <th>Payment</th><th>Status</th><th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <c:forEach var="b" items="${bookings}">
                <tr>
                    <td><c:out value="${b.id}"/></td>
                    <td><c:out value="${b.guestName}"/><br><small class="muted"><c:out value="${b.guestEmail}"/></small></td>
                    <td><c:out value="${b.roomNumber}"/> (<c:out value="${b.typeName}"/>)</td>
                    <td>
                        <fmt:formatDate value="${b.checkIn}" pattern="dd MMM"/> &rarr;
                        <fmt:formatDate value="${b.checkOut}" pattern="dd MMM yyyy"/>
                    </td>
                    <td>&#8377;<fmt:formatNumber value="${b.totalAmount}" pattern="#,##0"/></td>
                    <td><c:out value="${b.paymentMethod}"/><br><small><c:out value="${b.paymentStatus}"/></small></td>
                    <td><span class="status status-${b.status}"><c:out value="${b.status}"/></span></td>
                    <td class="row-actions">
                        <c:if test="${b.status == 'CONFIRMED'}">
                            <form action="${ctx}/admin/bookings" method="post">
                                <input type="hidden" name="action" value="checkin">
                                <input type="hidden" name="id" value="${b.id}">
                                <button class="btn btn-sm" type="submit">Check-in</button>
                            </form>
                            <form action="${ctx}/admin/bookings" method="post"
                                  onsubmit="return confirm('Cancel booking #${b.id}?');">
                                <input type="hidden" name="action" value="cancel">
                                <input type="hidden" name="id" value="${b.id}">
                                <button class="btn btn-sm btn-outline" type="submit">Cancel</button>
                            </form>
                        </c:if>
                        <c:if test="${b.status == 'CHECKED_IN'}">
                            <form action="${ctx}/admin/bookings" method="post">
                                <input type="hidden" name="action" value="checkout">
                                <input type="hidden" name="id" value="${b.id}">
                                <button class="btn btn-sm" type="submit">Check-out</button>
                            </form>
                        </c:if>
                        <form action="${ctx}/admin/bookings" method="post"
                              onsubmit="return confirm('Permanently delete booking #${b.id}?');">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="${b.id}">
                            <button class="btn btn-sm btn-danger" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            </c:forEach>
            </tbody>
        </table>
    </c:otherwise>
</c:choose>

<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
