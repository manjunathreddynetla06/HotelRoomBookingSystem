<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<jsp:include page="/WEB-INF/views/common/header.jsp"/>

<div class="page-head">
    <h2>Manage rooms</h2>
    <a class="btn" href="${ctx}/admin/rooms?action=new">+ Add room</a>
</div>

<table class="table table-striped">
    <thead>
    <tr><th>Room</th><th>Type</th><th>Floor</th><th>Capacity</th><th>Price / night</th><th>Status</th><th>Actions</th></tr>
    </thead>
    <tbody>
    <c:forEach var="r" items="${rooms}">
        <tr>
            <td><c:out value="${r.roomNumber}"/></td>
            <td><c:out value="${r.typeName}"/></td>
            <td><c:out value="${r.floorNo}"/></td>
            <td><c:out value="${r.capacity}"/></td>
            <td>&#8377;<fmt:formatNumber value="${r.pricePerNight}" pattern="#,##0"/></td>
            <td><span class="status status-${r.status}"><c:out value="${r.status}"/></span></td>
            <td class="row-actions">
                <a class="btn btn-sm btn-outline" href="${ctx}/admin/rooms?action=edit&amp;id=${r.id}">Edit</a>
                <form action="${ctx}/admin/rooms" method="post"
                      onsubmit="return confirm('Delete room ${r.roomNumber}?');">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="${r.id}">
                    <button class="btn btn-sm btn-danger" type="submit">Delete</button>
                </form>
            </td>
        </tr>
    </c:forEach>
    </tbody>
</table>

<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
