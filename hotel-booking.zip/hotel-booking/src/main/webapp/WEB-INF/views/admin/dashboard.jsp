<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<jsp:include page="/WEB-INF/views/common/header.jsp"/>

<h2>Admin dashboard</h2>

<div class="stats">
    <div class="stat"><span class="num"><c:out value="${stats.totalRooms}"/></span><span>Total rooms</span></div>
    <div class="stat"><span class="num"><c:out value="${stats.totalGuests}"/></span><span>Registered guests</span></div>
    <div class="stat"><span class="num"><c:out value="${stats.activeBookings}"/></span><span>Active bookings</span></div>
    <div class="stat"><span class="num"><c:out value="${stats.todayCheckIns}"/></span><span>Check-ins today</span></div>
    <div class="stat"><span class="num">&#8377;<fmt:formatNumber value="${stats.revenue}" pattern="#,##0"/></span><span>Revenue collected</span></div>
</div>

<div class="actions">
    <a class="btn" href="${ctx}/admin/rooms">Manage rooms</a>
    <a class="btn btn-outline" href="${ctx}/admin/bookings">View all bookings</a>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
