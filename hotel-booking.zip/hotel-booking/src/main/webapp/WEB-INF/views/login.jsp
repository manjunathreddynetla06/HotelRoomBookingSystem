<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<jsp:include page="/WEB-INF/views/common/header.jsp"/>

<div class="form-box">
    <h2>Login</h2>
    <form action="${ctx}/login" method="post" onsubmit="return validateLogin(this);">
        <label>Email
            <input type="email" name="email" value="<c:out value='${email}'/>" required>
        </label>
        <label>Password
            <input type="password" name="password" required>
        </label>
        <button class="btn btn-block" type="submit">Login</button>
    </form>
    <p class="muted">New guest? <a href="${ctx}/register">Create an account</a></p>
</div>

<script src="${ctx}/js/validate.js"></script>
<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
