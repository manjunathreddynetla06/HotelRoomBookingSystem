<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<jsp:include page="/WEB-INF/views/common/header.jsp"/>

<div class="form-box">
    <h2>Create account</h2>

    <c:if test="${not empty errors}">
        <div class="alert alert-error">
            <ul>
                <c:forEach var="e" items="${errors}">
                    <li><c:out value="${e}"/></li>
                </c:forEach>
            </ul>
        </div>
    </c:if>

    <form action="${ctx}/register" method="post" onsubmit="return validateRegister(this);">
        <label>Full name
            <input type="text" name="fullName" value="<c:out value='${fullName}'/>" minlength="3" maxlength="100" required>
        </label>
        <label>Email
            <input type="email" name="email" value="<c:out value='${email}'/>" required>
        </label>
        <label>Mobile number
            <input type="tel" name="phone" value="<c:out value='${phone}'/>" pattern="[6-9][0-9]{9}" maxlength="10" required>
        </label>
        <label>Password (min 6 characters)
            <input type="password" name="password" minlength="6" required>
        </label>
        <label>Confirm password
            <input type="password" name="confirm" minlength="6" required>
        </label>
        <button class="btn btn-block" type="submit">Register</button>
    </form>
    <p class="muted">Already registered? <a href="${ctx}/login">Login</a></p>
</div>

<script src="${ctx}/js/validate.js"></script>
<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
