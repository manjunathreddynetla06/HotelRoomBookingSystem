<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<jsp:include page="/WEB-INF/views/common/header.jsp"/>

<h2>My bookings</h2>

<c:choose>
    <c:when test="${empty bookings}">
        <div class="alert alert-info">You have no bookings yet. <a href="${ctx}/rooms">Browse rooms</a></div>
    </c:when>
    <c:otherwise>
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Guests</th>
                <th>Total</th><th>Payment</th><th>Status</th><th></th>
            </tr>
            </thead>
            <tbody>
            <c:forEach var="b" items="${bookings}">
                <tr>
                    <td><c:out value="${b.id}"/></td>
                    <td><c:out value="${b.roomNumber}"/> (<c:out value="${b.typeName}"/>)</td>
                    <td><fmt:formatDate value="${b.checkIn}" pattern="dd MMM yyyy"/></td>
                    <td><fmt:formatDate value="${b.checkOut}" pattern="dd MMM yyyy"/></td>
                    <td><c:out value="${b.guests}"/></td>
                    <td>&#8377;<fmt:formatNumber value="${b.totalAmount}" pattern="#,##0.00"/></td>
                    <td><c:out value="${b.paymentMethod}"/> / <c:out value="${b.paymentStatus}"/></td>
                    <td><span class="status status-${b.status}"><c:out value="${b.status}"/></span></td>
                    <td>
                        <c:if test="${b.status == 'CONFIRMED'}">
                            <form action="${ctx}/cancel" method="post"
                                  onsubmit="return confirm('Cancel booking #${b.id}?');">
                                <input type="hidden" name="bookingId" value="${b.id}">
                                <button class="btn btn-sm btn-danger" type="submit">Cancel</button>
                            </form>
                        </c:if>
                    </td>
                </tr>
            </c:forEach>
            </tbody>
        </table>
    </c:otherwise>
</c:choose>

<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
