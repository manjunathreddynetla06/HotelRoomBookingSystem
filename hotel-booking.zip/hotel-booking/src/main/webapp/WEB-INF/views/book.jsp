<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<jsp:include page="/WEB-INF/views/common/header.jsp"/>

<h2>Confirm your booking</h2>

<div class="two-col">
    <div class="card">
        <h3>Room <c:out value="${room.roomNumber}"/> &middot; <c:out value="${room.typeName}"/></h3>
        <p><c:out value="${room.description}"/></p>
        <table class="table">
            <tr><th>Check-in</th><td><c:out value="${checkIn}"/></td></tr>
            <tr><th>Check-out</th><td><c:out value="${checkOut}"/></td></tr>
            <tr><th>Nights</th><td><c:out value="${nights}"/></td></tr>
            <tr><th>Guests</th><td><c:out value="${guests}"/></td></tr>
            <tr><th>Rate</th><td>&#8377;<fmt:formatNumber value="${room.pricePerNight}" pattern="#,##0.00"/> / night</td></tr>
            <tr class="total"><th>Total</th><td>&#8377;<fmt:formatNumber value="${total}" pattern="#,##0.00"/></td></tr>
        </table>
    </div>

    <div class="card">
        <h3>Payment</h3>
        <form action="${ctx}/book" method="post">
            <input type="hidden" name="roomId" value="${room.id}">
            <input type="hidden" name="checkIn" value="${checkIn}">
            <input type="hidden" name="checkOut" value="${checkOut}">
            <input type="hidden" name="guests" value="${guests}">

            <label class="radio"><input type="radio" name="paymentMethod" value="CARD" required> Credit / Debit card</label>
            <label class="radio"><input type="radio" name="paymentMethod" value="UPI"> UPI</label>
            <label class="radio"><input type="radio" name="paymentMethod" value="PAY_AT_HOTEL"> Pay at hotel</label>

            <p class="muted">Payment is simulated for this academic project.</p>
            <button class="btn btn-block" type="submit">Confirm booking</button>
            <a class="btn btn-block btn-outline" href="${ctx}/rooms?checkIn=${checkIn}&amp;checkOut=${checkOut}&amp;guests=${guests}">Back</a>
        </form>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
