<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" isErrorPage="true" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<jsp:include page="/WEB-INF/views/common/header.jsp"/>

<div class="form-box">
    <h2>Something went wrong</h2>
    <p>The page you asked for could not be shown. This may be a missing page, a permissions problem, or a temporary error.</p>
    <a class="btn" href="${ctx}/">Back to home</a>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
