</main>
<footer class="footer">
    <div class="container">&copy; 2026 Grand Stay Hotel &middot; Hotel Room Booking Management System &middot; AJT Project</div>
</footer>
</body>
</html>
