<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}" scope="request"/>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Grand Stay Hotel</title>
    <link rel="stylesheet" href="${ctx}/css/style.css">
</head>
<body>
<header class="nav">
    <div class="container nav-inner">
        <a class="brand" href="${ctx}/">&#127976; Grand Stay</a>
        <nav>
            <a href="${ctx}/rooms">Rooms</a>
            <c:choose>
                <c:when test="${empty sessionScope.user}">
                    <a href="${ctx}/login">Login</a>
                    <a class="btn btn-sm" href="${ctx}/register">Register</a>
                </c:when>
                <c:otherwise>
                    <c:if test="${sessionScope.user.admin}">
                        <a href="${ctx}/admin/dashboard">Dashboard</a>
                        <a href="${ctx}/admin/rooms">Manage Rooms</a>
                        <a href="${ctx}/admin/bookings">All Bookings</a>
                    </c:if>
                    <c:if test="${not sessionScope.user.admin}">
                        <a href="${ctx}/my-bookings">My Bookings</a>
                    </c:if>
                    <span class="hello">Hi, <c:out value="${sessionScope.user.fullName}"/></span>
                    <a class="btn btn-sm btn-outline" href="${ctx}/logout">Logout</a>
                </c:otherwise>
            </c:choose>
        </nav>
    </div>
</header>
<main class="container">
    <c:if test="${not empty sessionScope.flash}">
        <div class="alert alert-info"><c:out value="${sessionScope.flash}"/></div>
        <c:remove var="flash" scope="session"/>
    </c:if>
    <c:if test="${not empty requestScope.error}">
        <div class="alert alert-error"><c:out value="${requestScope.error}"/></div>
    </c:if>
