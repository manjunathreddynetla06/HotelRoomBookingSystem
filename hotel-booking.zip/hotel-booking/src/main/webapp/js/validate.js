/* Client-side form validation (server validates again). */

function validateSearch(f) {
    var inD = new Date(f.checkIn.value);
    var outD = new Date(f.checkOut.value);
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    if (isNaN(inD) || isNaN(outD)) {
        alert("Please choose both dates.");
        return false;
    }
    if (inD < today) {
        alert("Check-in date cannot be in the past.");
        return false;
    }
    if (outD <= inD) {
        alert("Check-out must be after check-in.");
        return false;
    }
    return true;
}

function validateLogin(f) {
    var re = /^[\w.+-]+@[\w-]+(\.[\w-]+)+$/;
    if (!re.test(f.email.value.trim())) {
        alert("Enter a valid email address.");
        return false;
    }
    if (f.password.value.length === 0) {
        alert("Enter your password.");
        return false;
    }
    return true;
}

function validateRegister(f) {
    if (f.fullName.value.trim().length < 3) {
        alert("Name must be at least 3 characters.");
        return false;
    }
    if (!/^[6-9]\d{9}$/.test(f.phone.value.trim())) {
        alert("Enter a valid 10 digit mobile number.");
        return false;
    }
    if (f.password.value.length < 6) {
        alert("Password must be at least 6 characters.");
        return false;
    }
    if (f.password.value !== f.confirm.value) {
        alert("Passwords do not match.");
        return false;
    }
    return true;
}
