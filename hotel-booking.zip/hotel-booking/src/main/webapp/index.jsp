<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%
    // set today's date for the date picker min attribute
    request.setAttribute("today", java.time.LocalDate.now().toString());
    request.setAttribute("tomorrow", java.time.LocalDate.now().plusDays(1).toString());
%>
<jsp:include page="/WEB-INF/views/common/header.jsp"/>

<section class="hero">
    <h1>Find your perfect stay</h1>
    <p>Comfortable rooms, instant confirmation, best prices.</p>
    <form class="search-form" action="${ctx}/rooms" method="get" onsubmit="return validateSearch(this);">
        <label>Check-in
            <input type="date" name="checkIn" min="${today}" value="${today}" required>
        </label>
        <label>Check-out
            <input type="date" name="checkOut" min="${tomorrow}" value="${tomorrow}" required>
        </label>
        <label>Guests
            <input type="number" name="guests" min="1" max="10" value="2" required>
        </label>
        <button class="btn" type="submit">Search rooms</button>
    </form>
</section>

<section class="features">
    <div class="card"><h3>&#128719; Standard</h3><p>AC room with TV and Wi-Fi from &#8377;1,500 / night.</p></div>
    <div class="card"><h3>&#127750; Deluxe</h3><p>City view and breakfast from &#8377;2,800 / night.</p></div>
    <div class="card"><h3>&#128081; Suite</h3><p>Luxury living area and bathtub from &#8377;5,500 / night.</p></div>
</section>

<script src="${ctx}/js/validate.js"></script>
<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
