# Hotel Room Booking Management System

**Subject:** Advanced Java Technologies (01CE0308) &nbsp;|&nbsp; **Branch:** Computer Engineering, Semester 3

An enterprise-style web application built with **Servlets, JSP, JSTL & EL, JDBC, Filters and Session Management** on a layered architecture (Controller → DAO → Database).

## Features

**Guest**
- Register / login / logout (SHA-256 hashed passwords)
- Search rooms by check-in, check-out and guests (live availability, no double booking)
- Book a room with a (simulated) payment method
- View and cancel own bookings

**Admin**
- Dashboard (rooms, guests, active bookings, today's check-ins, revenue)
- Room management: add / edit / delete rooms (full CRUD)
- Booking management: check-in, check-out, cancel, delete

## Technologies mapped to the rubric

| Rubric item | Where in the code |
|---|---|
| Database (3+ related tables) | `database/schema.sql` — `users`, `room_types`, `rooms`, `bookings`, `payments` with foreign keys |
| JDBC connectivity | `com.hotel.util.DBConnection`, `db.properties` |
| CRUD operations | `UserDAO`, `RoomDAO`, `BookingDAO` (PreparedStatement everywhere) |
| Transactions | `BookingDAO.create()` / `cancel()` (commit, rollback, `SELECT … FOR UPDATE`) |
| Exception handling | `AppException`, SQL error codes (duplicate email, FK violation) mapped to friendly messages, global error pages in `web.xml` |
| Servlets | `com.hotel.servlet.*` (11 servlets, `doGet`/`doPost`, Post-Redirect-Get) |
| JSP + JSTL + EL | `WEB-INF/views/**` (`c:if`, `c:forEach`, `c:choose`, `c:out`, `fmt:*`, `fn:*`) |
| Form validation | Client side: `js/validate.js` + HTML5 attributes. Server side: in every servlet |
| Session management | Login stores `User` in `HttpSession`, 30 min timeout, session-fixation protection, flash messages, `AuthFilter` / `AdminFilter` |
| Layered architecture | model → dao → servlet → JSP |

## Project structure

```
hotel-booking/
├── database/schema.sql
├── pom.xml
└── src/main
    ├── java/com/hotel
    │   ├── dao/        UserDAO, RoomDAO, BookingDAO
    │   ├── exception/  AppException
    │   ├── filter/     AuthFilter, AdminFilter, EncodingFilter
    │   ├── model/      User, Room, RoomType, Booking
    │   ├── servlet/    Login, Register, Logout, RoomSearch, Booking, MyBookings,
    │   │               CancelBooking, AdminDashboard, AdminRoom, AdminBooking
    │   └── util/       DBConnection, PasswordUtil
    ├── resources/db.properties
    └── webapp
        ├── index.jsp, css/, js/
        └── WEB-INF/ web.xml, views/ (guest pages), views/admin/, views/common/
```

## Database (ER summary)

```
users 1 ───< bookings >─── 1 rooms >─── 1 room_types
                 │
                 1
                 └──< payments
```

## How to run

**Requirements:** JDK 11+, Maven 3.6+, MySQL 8, Apache Tomcat 9 (uses `javax.servlet`; do NOT use Tomcat 10+).

1. **Create the database**
   ```bash
   mysql -u root -p < database/schema.sql
   ```
2. **Set your MySQL password** in `src/main/resources/db.properties`.
3. **Build the WAR**
   ```bash
   mvn clean package
   ```
4. **Deploy:** copy `target/hotel-booking.war` into Tomcat's `webapps/` folder and start Tomcat, or run it from Eclipse/IntelliJ/NetBeans with a Tomcat 9 server configuration.
5. Open **http://localhost:8080/hotel-booking/**

### Default admin login
- Email: `admin@hotel.com`
- Password: `admin123`

Guests register themselves from the Register page.

## Deployment (for the "deployed application link")
Any Java host that supports WAR files and MySQL works, e.g. Railway, Render (Docker) or a cloud VM with Tomcat. Set the database URL, user and password in `db.properties` before building.

## Notes
- Payment is simulated (no real gateway).
- Passwords are SHA-256 hashed for simplicity; a production system should use bcrypt/argon2 with a salt.
