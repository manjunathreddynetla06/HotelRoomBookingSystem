-- =====================================================
-- Hotel Room Booking Management System - MySQL Schema
-- =====================================================
DROP DATABASE IF EXISTS hotel_db;
CREATE DATABASE hotel_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hotel_db;

-- 1. USERS (guests and admins)
CREATE TABLE users (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    full_name     VARCHAR(100) NOT NULL,
    email         VARCHAR(120) NOT NULL UNIQUE,
    phone         VARCHAR(15)  NOT NULL,
    password_hash VARCHAR(64)  NOT NULL,
    role          ENUM('ADMIN','GUEST') NOT NULL DEFAULT 'GUEST',
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. ROOM TYPES (Standard, Deluxe, Suite ...)
CREATE TABLE room_types (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(50)   NOT NULL UNIQUE,
    description     VARCHAR(255),
    price_per_night DECIMAL(10,2) NOT NULL CHECK (price_per_night > 0),
    capacity        INT NOT NULL CHECK (capacity > 0)
) ENGINE=InnoDB;

-- 3. ROOMS
CREATE TABLE rooms (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(10) NOT NULL UNIQUE,
    type_id     INT NOT NULL,
    floor_no    INT NOT NULL,
    status      ENUM('ACTIVE','MAINTENANCE') NOT NULL DEFAULT 'ACTIVE',
    CONSTRAINT fk_room_type FOREIGN KEY (type_id) REFERENCES room_types(id)
) ENGINE=InnoDB;

-- 4. BOOKINGS
CREATE TABLE bookings (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT NOT NULL,
    room_id      INT NOT NULL,
    check_in     DATE NOT NULL,
    check_out    DATE NOT NULL,
    guests       INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status       ENUM('CONFIRMED','CHECKED_IN','CHECKED_OUT','CANCELLED') NOT NULL DEFAULT 'CONFIRMED',
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_booking_user FOREIGN KEY (user_id) REFERENCES users(id),
    CONSTRAINT fk_booking_room FOREIGN KEY (room_id) REFERENCES rooms(id),
    CONSTRAINT chk_dates CHECK (check_out > check_in)
) ENGINE=InnoDB;

-- 5. PAYMENTS
CREATE TABLE payments (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    amount     DECIMAL(10,2) NOT NULL,
    method     ENUM('CARD','UPI','PAY_AT_HOTEL') NOT NULL,
    status     ENUM('PENDING','PAID','REFUNDED') NOT NULL DEFAULT 'PENDING',
    paid_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_payment_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE INDEX idx_booking_room_dates ON bookings(room_id, check_in, check_out);

-- ================= SEED DATA =================
-- Admin login: admin@hotel.com / admin123  (SHA-256 hashed)
INSERT INTO users (full_name, email, phone, password_hash, role) VALUES
('Hotel Admin', 'admin@hotel.com', '9999999999',
 '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'ADMIN');

INSERT INTO room_types (name, description, price_per_night, capacity) VALUES
('Standard', 'Comfortable room with AC, TV and Wi-Fi', 1500.00, 2),
('Deluxe',   'Spacious room with city view and breakfast', 2800.00, 3),
('Suite',    'Luxury suite with living area and bathtub', 5500.00, 4);

INSERT INTO rooms (room_number, type_id, floor_no, status) VALUES
('101', 1, 1, 'ACTIVE'), ('102', 1, 1, 'ACTIVE'), ('103', 1, 1, 'ACTIVE'),
('201', 2, 2, 'ACTIVE'), ('202', 2, 2, 'ACTIVE'), ('203', 2, 2, 'MAINTENANCE'),
('301', 3, 3, 'ACTIVE'), ('302', 3, 3, 'ACTIVE');
